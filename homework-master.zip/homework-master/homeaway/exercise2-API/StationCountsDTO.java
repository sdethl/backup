package com.fiserv.edd.platform.qa.operation.user;

import java.io.Serializable;

/**
 * Created by holiao on 4/3/2016.
 */
public class StationCountsDTO implements Serializable {


}
