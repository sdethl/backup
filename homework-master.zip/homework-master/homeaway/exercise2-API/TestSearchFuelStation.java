/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.fiserv.edd.platform.qa.operation.tests;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;
import org.apache.log4j.Logger;
import org.junit.After;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import javax.ws.rs.WebApplicationException;

/**
 *
 * @author holiao
 */
public class TestSearchFuelStation {
    
    static final Logger logger = Logger.getLogger(TestSearchFuelStation.class);

    @Before
    public void setUp() {
        
    }
    
    @After
    public void tearDown() {
        
    }

    @Test
    public void testSearchResult(){
        FuelStationsAPI fsapi = new FuelStationsAPI();
        FuelStationsDTO result = fsapi.searchBy();
        assertNotNull(result);
    }

    @Test
    public void testSearchAddressById(){

    }
}
