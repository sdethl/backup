package com.fiserv.edd.platform.qa.operation.user;

import java.io.Serializable;

/**
 * Created by holiao on 4/3/2016.
 */
public class FuelStationsDTO implements Serializable {

    /**
     * This is partial of the DTO.
     * A specific DTO should contain gets and sets for all the columns.
     */
    private Integer id;
    private String stationName;
    private String streetAddress;
    private String state;
    private String city;
    private String zipCode;
    private String evNetwork;

    public FuelStationsDTO(){
        
    }

    public Integer getStationId(){ return this.id; }
    public String getStationName(){ return this.stationName; }
    public String getStreetAddress(){return  this.streetAddress;}
    public String getState(){return this.state;}
    public String getCity(){return  this.city;}
    public String getZipCode(){return this.zipCode;}
    public String getEvNetwork(){return this.evNetwork;}

}
