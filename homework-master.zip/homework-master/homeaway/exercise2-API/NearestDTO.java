package com.fiserv.edd.platform.qa.operation.user;

import java.io.Serializable;
/**
 * Created by holiao on 4/3/2016.
 */
public class NearestDTO implements Serializable {

    /**
     * This is partial of the DTO.
     * A specific DTO should contain gets and sets for all the columns.
     */
    private String latitude;
    private String longitude;
    private StationCountsDTO stationCounts;
    private FuelStationsDTO[] fuelStations;

    public NearestDTO(){

    }

    public String getLatitude(){ return this.latitude; }
    public String getLongitude(){return this.longitude;}
    public StationCountsDTO getStationCounts() { return this.stationCounts; }
    public FuelStationsDTO[] getFuelStations(){return this.fuelStations;}

}
