package com.fiserv.edd.platform.qa.operation.user;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;

import javax.ws.rs.WebApplicationException;

/**
 * Created by holiao on 4/3/2016.
 */
public class GetData {

    public NearestDTO doGet(){
        // Create Jersey client
        ClientConfig clientConfig = new DefaultClientConfig();
        clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);
        Client client = Client.create(clientConfig);

        String url = "https://api.data.gov/nrel/alt-fuel-stations/v1/nearest.json?api_key=ZEVywuKBUwTOmNym1Tyx8w9uFVGoKmHzXXx3SdM5&location=Austin";
        WebResource webResourceGet = client.resource(url);
        ClientResponse response = webResourceGet.get(ClientResponse.class);
        NearestDTO responseEntity = response.getEntity(NearestDTO.class);

        if (response.getStatus() != 200) {
            throw new WebApplicationException();
        }

        return responseEntity;
    }
}
