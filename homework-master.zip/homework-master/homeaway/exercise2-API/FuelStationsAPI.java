/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.fiserv.edd.platform.qa.operation.user;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;
import org.apache.log4j.Logger;
import com.sun.jersey.api.client.ClientResponse;

import javax.ws.rs.WebApplicationException;

/**
 * Created by holiao on 4/3/2016.
 */
public class FuelStationsAPI {
    
    public FuelStationsDTO searchBy(){

        FuelStationsDTO result = null;

        GetData data = new GetData();
        NearestDTO json = data.doGet();
        FuelStationsDTO[] results     = json.getFuelStations();
        FuelStationsDTO fsdto = new FuelStationsDTO();
        if (results.length != 0){
            for(int i=0; i<results.length; i++){
                String name = fsdto.getStationName();
                String network = fsdto.getEvNetwork();

            }
        }
        return result;
    }
}
