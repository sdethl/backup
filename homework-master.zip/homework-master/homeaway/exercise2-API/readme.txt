======================
Environment
======================
Java
IntelliJ
Jersey client

======================
Summary
======================
My java environment has the certificate issue, this is the error:

Exception in thread "main" com.sun.jersey.api.client.ClientHandlerException: javax.net.ssl.SSLHandshakeException: sun.security.validator.ValidatorException: PKIX path building failed: sun.security.provider.certpath.SunCertPathBuilderException: unable to find valid certification path to requested target

Unfortunately, I didn't have time to fix it at this point. But I still can demonstrate you my problem solving skills by providing critical code structure, I think.
This is my solution:

Step1: Using Jersey client to get the response back, and then transfer to a DTO;
Step2: I used a JSON validator to analyse the response structure, and defined these DTOs
	NearestDTO for the whole object
	FuelStationsDTO for the list of stations
	StationCountsDTO for the list of counts
Step3: FuelStationsAPI.java will get the DTO(s) and provide functions for searching data.
Step4: TestSearchFuelStation.java will do the test.

	
	

