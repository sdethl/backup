/**
 *
 * @author holiao
 */

var demoLoginPage = require('../pageobjects/demoLoginPageObj.js');
var demoUserProductPage = require('../pageobjects/demoUserProductPageObj.js');
var demoUserCheckoutPage = require('../pageobjects/demoUserCheckoutPageObj.js');
var demoUserReviewAndPurchasePage = require('../pageobjects/demoUserReviewAndPurchasePageObj.js');


/**
 * Define user story 
 * @returns {undefined}
 */

describe('Exercise 1', function () {

    beforeEach(function () {
        demoLoginPage.login('qauser','Storedemoqa.com');

    });

    afterEach(function(){
        demoLoginPage.logout();
    });

    it('Test Case 1: remove', function () {

        demoUserProductPage.buyThis(browser.params.baseUrl.userProduct);
        demoUserProductPage.clickCheckOut();
        demoUserCheckoutPage.clickRemove();
        demoUserCheckoutPage.expectedMessage("Oops, there is nothing in your cart.");
    });


    xit('Test Case 2: update', function () {

        demoUserProductPage.buyThis(browser.params.baseUrl.userProduct);
        demoUserProductPage.clickCheckOut();
        demoUserCheckoutPage.updateQuantity();
        demoUserCheckoutPage.clickContinue();
        browser.driver.sleep(2000);
    });

    xit('Test Case 3: verify price', function () {

        demoUserProductPage.buyThis(browser.params.baseUrl.userProduct);
        demoUserProductPage.clickCheckOut();
        demoUserCheckoutPage.updateQuantity(2);
        demoUserCheckoutPage.clickContinue();
        demoUserReviewAndPurchasePage.getTable();

    });



});



