/**
 *
 * @author holiao
 */

var env = require('./env/environment.js');
var baseUrl = require('./env/baseUrl.js');

exports.config = {

    seleniumAddress: env.seleniumAddress,
    capabilities: env.capabilities,
    framework: env.framework,
  
    suites: {
        test: ['./specs/spec.js']
    },

    params: {
        baseUrl:baseUrl,
        username: 'qauser',
        password: 'Storedemoqa.com'
    },
    
    onPrepare: function() {

  }
};