/**
 *
 * @author holiao
 */

var demoUserProductPage = require('../pageobjects/demoUserProductPageObj.js');


var Demo_LoginPage = function(){

    this.get = function(){        
        browser.driver.get( browser.params.baseUrl);
        browser.driver.manage().window().maximize();
        browser.driver.sleep(2000);
    };

    this.login = function(username, pwd){

        browser.driver.get( browser.params.baseUrl.yourAccount).then(function(){
            browser.driver.findElement(by.id('log')).clear();
            browser.driver.findElement(by.id('log')).sendKeys(username);

            browser.driver.findElement(by.id('pwd')).clear();
            browser.driver.findElement(by.id('pwd')).sendKeys(pwd);
        })
        browser.driver.findElement(by.id('login')).click();
        browser.driver.sleep(2000);
    };

    this.logout = function(){
        //todo
    };

};

module.exports = new Demo_LoginPage();