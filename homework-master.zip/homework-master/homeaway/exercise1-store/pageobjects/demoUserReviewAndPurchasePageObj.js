
/**
 *
 * @author holiao
 */

var Demo_UserReviewAndPurchasePage = function(){

    this.get = function(){

    };

    this.getTable = function(){
        browser.driver.findElement(by.css('.wpsc_checkout_table.table-4')).then(function(table){
            table.findElement(by.tagName('tbody')).then(function(tbody){
                tbody.findElements(by.tagName('tr')).then(function(rows){
                    for(i=0; i<rows.length;i++)
                    {
                        rows[i].findElements(by.tagName('td')).then(function(cols){
                            for(j=0; j<cols.length;j++){
                                console.log("text" + cols[j].getText());
                            };
                        });
                    };
                });
            });
        });
    };
};

module.exports = new Demo_UserReviewAndPurchasePage();