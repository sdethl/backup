/**
 *
 * @author holiao
 */

var demoUserReviewAndPurchasePage = require('../pageobjects/demoUserReviewAndPurchasePageObj.js');
//var webdriver = require('selenium-webdriver');

var Demo_UserCheckoutPage = function(){

    this.get = function(){        
        browser.driver.get( browser.params.baseUrl.checkout);
        browser.driver.manage().window().maximize();  
    };

    this.updateQuantity = function(){
        //browser.executeScript("browser.driver.findElement(by.css('.adjustform.qty')).setAttribute('quantity', '2')");
        browser.driver.findElement(by.css('.adjustform.qty')).submit();
        browser.driver.sleep(2000);

    };

    this.clickRemove = function(){
        browser.driver.findElement(by.css(".adjustform.remove")).submit();
    };

    this.clickContinue = function(){
        browser.driver.findElement(by.css('.step2')).click().then(function(){
            return demoUserReviewAndPurchasePage;
        });
    };

    this.expectedMessage = function(msg){
        browser.driver.findElement(by.css('.entry-content')).getText().then(function(text){
            console.log("message: "+ text);
            expect(msg).toBe(text);
            }
        );
    };
};

module.exports = new Demo_UserCheckoutPage();