
/**
 *
 * @author holiao
 */

var demoUserCheckoutPage = require('../pageobjects/demoUserCheckoutPageObj.js');

var Demo_UserProductPage = function(){

    this.get = function(){

    };

    this.buyThis = function(product){
        browser.driver.get( product).then(function (){
            browser.driver.manage().window().maximize();
            browser.driver.findElement(by.className('wpsc_buy_button')).click();
        });
        browser.driver.sleep(2000);
    };

    this.clickContinueShopping = function(){

    };

    this.clickCheckOut = function(){
        browser.driver.findElement(by.className('go_to_checkout')).click().then(function (){
            return demoUserCheckoutPage;
        });
        browser.driver.sleep(2000);
    };
};

module.exports = new Demo_UserProductPage();

