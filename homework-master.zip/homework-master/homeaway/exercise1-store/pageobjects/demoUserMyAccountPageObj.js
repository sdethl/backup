//var evSecurityChallengeMfaPage = require('../pageobjects/evSecurityChallengeMfaPageObj.js');

var EV_LoginPage = function(){

    this.get = function(){        
        browser.driver.get( browser.params.baseUrl);
        browser.driver.manage().window().maximize();  
    };

    this.login = function(username, pwd){
        browser.driver.get( browser.params.yourAccount);
        browser.driver.findElement(by.id('log')).clear();
        browser.driver.findElement(by.id('log')).sendKeys(username);
        browser.driver.findElement(by.id('pwd')).clear();
        browser.driver.findElement(by.id('pwd')).sendKeys(pwd);
        browser.driver.findElement(by.id('login')).click();
    };

    this.logout = function(){

    };

    this.buy = function(){
        browser.driver.get( browser.params.buy);
        browser.driver.sleep(2000);
        browser.driver.findElement(by.className('wpsc_buy_button')).click();
        browser.driver.sleep(2000);
    };

    this.continueShopping = function(){

    };

    this.checkOut = function(){
        browser.driver.findElement(by.className('go_to_checkout')).click();
        browser.driver.sleep(2000);

    };



    //this.iForgotMyPassword =function(){
    //    element(by.id('forgot_password_link')).click();
    //    return evPasswordResetPage;
    //};
    //
    //this.logOut = function(){
    //    element(by.id('Banner_Signout')).click();
    //};
};

module.exports = new EV_LoginPage();