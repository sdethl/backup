/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


 // Common configuration files with defaults plus overrides from environment vars
var webServerDefaultPort = 8080;

module.exports = {
  // The address of a running selenium server.
  //seleniumAddress:
  //  ('http://localhost:4444/wd/hub'),

  // Capabilities to be passed to the webdriver instance.
  capabilities: {
    'browserName':    ('chrome'),
    'version':        ('ANY'),    
    
    //For page to load
    'getPageTimeout' : ('2000'), //default 10
    //For Page synchronizaiton
    'allScriptsTimeout': ('2000'), //default 11
    //Selenium command time limit
    'command-timeout': ('2000'),//default 300
    //From Jasmine
    //'jasmineNodeOpts' : ('80'), //default 30    
     jasmineNodeOpts: {
    // onComplete will be called just before the driver quits.
    onComplete: null,
    // If true, display spec names.
    isVerbose: true,
    // If true, print colors to the terminal.
    showColors: true,
    // If true, include stack traces in failures.
    includeStackTrace: true,
    // Default time to wait in ms before a test fails.
    defaultTimeoutInterval: 120*1000
  },

    
    //Idel timeout
    'idle-duration': ('8000') //default 90
  },

  // Default http port to host the web server
  webServerDefaultPort: webServerDefaultPort,
  framework: 'jasmine2'

};