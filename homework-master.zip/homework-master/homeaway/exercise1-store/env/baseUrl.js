
/**
 *
 * @author holiao
 */

module.exports = {

    demoqa:'http://store.demoqa.com',
    userProduct:'http://store.demoqa.com/products-page/product-category/iphones/apple-iphone-4s-16gb-sim-free-black/',
    yourAccount: 'http://store.demoqa.com/products-page/your-account/',
    checkout: 'http://store.demoqa.com/products-page/checkout/'

};
