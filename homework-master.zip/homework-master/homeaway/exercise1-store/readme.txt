================
Environment:
================

Node.js
Protractor
Jasmine
Selenium standalone
Browser installations
IntelliJ IDEA

=====================
How to run the tests
=====================
>\homeaway\exercise1-store\protractor conf.js 

=================
Summary:
=================
I decided using Protractor since I'm using Protractor for my current projects. However, Protractor is for angularJS websites, so I need to make it work with workarounds. 

The execution entrance is conf.js.
The test cases are in the spec folder.
The env directory has environment configuration files. You can change the browser type to 'firefox' or 'Internet Explore'.
The page objects are designed according to the business work-flow.
The data directory should have expected result data.

===================
Test Result
===================
1. Remove:
Test case is passed. 
2. Update:
I couldn't get 'set the input value' work. Searched a bit and seemed like Protractor's issue. 
3. Verify price
Has issue getting values from the table. 






