var env = require('../eStatement.env/environment.js');

var baseUrl = require('../eStatement.env/local/urls/baseUrl.js');
var urls = require('../eStatement.env/local/urls/urls.js');

var expectedUrl = require('../eStatement.data/eStatementData_expectedUrl.js');
var tokens = require('../eStatement.data/eStatementData_tokens.js');
var message = require('../eStatement.data/eStatementData_errorMessages.js');

var securityLevel = require('./data/evData_securityLevel.js');
var users = require('./data/evData_users.js');

var HtmlReporter = require('protractor-jasmine2-screenshot-reporter');
var reporter = new HtmlReporter({
    dest: 'C:/Platform-EndToEnd-TestResults/EFT/Tests/'
    , docTitle: 'Enterprise View'
    , filename: 'EFT.html'
    , takeScreenShotsOnlyForFailedTests: false
});

exports.config = {

    seleniumAddress: env.seleniumAddress,
    capabilities: env.capabilities,
    framework: env.framework,

    suites: {

        /**
         * User Add feature suite
         */
        UserAdd:    'specs/eft/eftUserAddTest.js',//TC319
        Save: 'specs/eft/eftUserAddTest_SaveButton.js',//TC322
        SecurityLevel: 'specs/eft/eftUserAddTest_SecurityLevel.js',//TC325
        Username:   'specs/eft/eftUserAddTest_Username.js',//TC321
        Cancel: 'specs/eft/eftUserAddTest_CancelButton.js',//TC326
        Email:  'specs/eft/eftUserAddTest_Email.js',//TC320
        IC: 'specs/eft/eftUserAddTest_IdentifierCategories.js',//TC323
        RC: 'specs/eft/eftUserAddTest_ReportCategories.js',//TC324

        /**
         * User View feature suite
         */
        UserView: 'specs/eft/eftUserViewTest_UpdateProfile.js',//TC318
        UserViewCancel: 'specs/eft/eftUserViewTest_UpdateProfile_CancelButton.js',//TC329
        UserViewSave: 'specs/eft/eftUserViewTest_UpdateProfile_SaveButton.js',//TC328
        UserViewEmail: 'specs/eft/eftUserViewTest_UpdateProfile_Email.js',//TC327
        UserViewSL: 'specs/eft/eftUserViewTest_UpdateProfile_SecurityLevel.js',//TC344

        UserViewDA: 'specs/eft/eftUserViewTest_DocumentAccess.js',//TC330
        UserViewDASave: 'specs/eft/eftUserViewTest_DocumentAccess_SaveButton.js',//TC331
        UserViewDACancel: 'specs/eft/eftUserViewTest_DocumentAccess_CancelButton.js',//TC332

        /**
         * DocumentEFT/Report feature suite
         */
        SingleView: 'specs/eft/eftDocumentReportSingleViewTest.js',//TC333
        CriteriaSaveM: 'specs/eft/eftDocumentReportTest_SaveDownloadCriteria.js',//TC339, TC342, TC340
        CriteriaSaveSingle: 'specs/eft/eftDocumentReportTest_SaveDownloadCriteriaSingle.js',//TC339, TC342, TC340
        //Download:'specs/eft/eftDocumentReportDownloadTest.js',

        /**
         * DocumentEFT/Criteria Search feature suite
         */
        Criteria: 'specs/eft/eftDocumentCriteriaTest.js',
        SCPanel: 'specs/eft/eftDocumentCriteriaTest_SearchCriteriaPanel.js',

        /**
         * DocumentEFT/Bulk Search feature suite
         */
        Bulk: 'specs/eft/eftDocumentBulkTest.js',

        /**
         * Self Service suite
         */
        HM: 'specs/eft/eftSelfServiceOrderOptTest_HistoricalMatrix.js'


    },

    params: {
        baseUrl: baseUrl.ssoEntrance,
        urls:   urls,
        tokens: tokens,
        expectedUrl: expectedUrl,
        message: message,
        securityLevel:securityLevel,
        users:users
    },

    onPrepare: function() {
        jasmine.getEnv().addReporter(reporter);
    }
};