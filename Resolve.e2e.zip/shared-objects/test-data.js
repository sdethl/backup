module.exports = {
    url_search: "https://qa.s3betaplatform.com/search",
    url_person: "https://qa.s3betaplatform.com/info/person/1/main",
    url_lien: "https://qa.s3betaplatform.com/info/lien/1000/main",
    url_lien_details: "https://qa.s3betaplatform.com/info/lien/1000/details",
    url_lien_documents: "https://qa.s3betaplatform.com/info/lien/1000/documents"
};