

module.exports = function () {

    this.When(/^I land on the lien main page$/, function () {
        return helpers.loadPage(shared.testData.url_lien);
    });

    this.When(/^I land on the lien Details page$/, function () {
        return helpers.loadPage(shared.testData.url_lien_details);
    });

    this.When(/^I land on the lien Documents page$/, function () {
        return helpers.loadPage(shared.testData.url_lien_documents);
    });
};
