

module.exports = function () {

    this.When(/^I search RESOLVE for person with ID "([^"]*)"$/, function (searchQuery) {
        return helpers.loadPage(shared.testData.url_search).then(function() {
            return page.advanceSearch.selectAndPerformSearch(searchQuery);
        });
    });


    this.Then(/^I should see person "([^"]*)" in the results$/, function (keywords) {
        return driver.wait(until.elementsLocated(by.partialLinkText(keywords)));
    });


    this.Then(/^I should see some person results$/, function () {
        return driver.wait(until.elementsLocated(by.css('div.g'))).then(function() {
            return driver.findElements(by.css('div.g'));
        })
        .then(function (elements) {
            expect(elements.length).to.not.equal(0);
        });
    });


    this.Then(/^I should see "([^"]*)" user message in person search result/, function (keywords) {
        return driver.wait(until.elementsLocated(by.className("base-data-table__col search-result__no-matches-found")));
    });
};
