

module.exports = function () {

    this.Given(/^I'm a logged in admin user$/, function () {
        // todo: implement login test case when the feature becomes available

    });
    this.When(/^I land on the person main page$/, function () {
        return helpers.loadPage(shared.testData.url_person);
    });
    this.Then(/^I should see "([^"]*)" tab as a default page$/, function (arg1) {
        return driver.getCurrentUrl().then(function(url){
            assert(url === shared.testData.url_person);
        });
    });

    this.Then(/^I should see "([^"]*)" information$/, function (name) {
        return page.person.verifyModuleName(name);
    });

};
