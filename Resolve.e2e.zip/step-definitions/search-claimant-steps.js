module.exports = function () {

    this.Given(/^User is on Search Page$/, function () {
        return helpers.loadPage(shared.testData.url_search);
    });

    this.When(/^I search RESOLVE for claimant with ID "([^"]*)"$/, function (searchQuery) {
        return page.search.preformSearch(searchQuery);

    });


    this.Then(/^I should see "([^"]*)" in the results$/, function (keywords) {
        return driver.wait(until.elementsLocated(by.partialLinkText(keywords)));
    });


    this.Then(/^I should see some results$/, function () {
        return driver.wait(until.elementsLocated(by.css('div.search-result'))).then(function() {
            return driver.findElements(by.css('div.search-result'));
        })
        .then(function (elements) {
            expect(elements.length).to.not.equal(0);
        });
    });


    this.Then(/^I should see "([^"]*)" user message in claimant search result$/, function (keywords) {
        return driver.wait(until.elementsLocated(by.className("base-data-table__no-results-lable")));
    });
};
