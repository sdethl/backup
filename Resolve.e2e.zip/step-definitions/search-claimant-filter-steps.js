var testData = require('../shared-objects/test-data')

module.exports = function () {

    this.When(/^I search RESOLVE for claimant with first name "([^"]*)" and last name "([^"]*)"$/, function (firstName, lastName) {
        return helpers.loadPage(testData.url_search).then(function() {
            return page.advanceSearchClaimant.preformSearch(firstName, lastName);
        });
    });


    this.Then(/^I should see "([^"]*)"$/, function (keywords) {
        return driver.wait(until.elementsLocated(by.partialLinkText(keywords)), 20000);
    });
};
