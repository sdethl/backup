module.exports = {

    elements: {
        module_glance: by.xpath('//h2[contains(text(),\'At A Glance\')]')
    },

    verifyModels: function (moduleName) {
        var title = page.Claimant.elements.module_glance;
        return driver.wait(until.elementsLocated(by.partialLinkText(keywords)), 10000);
    }

};