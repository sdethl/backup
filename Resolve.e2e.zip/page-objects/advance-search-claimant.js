module.exports = {

    elements: {
        searchCriteria_FirstName: by.id('firstName'),
        searchCriteria_LastName: by.id('lastName'),
        searchButton: by.className('ura-button ura-button search-toolbar__button ura-button__primary')
    },

    preformSearch: function (firstName, lastName) {
        var fn = page.advanceSearchClaimant.elements.searchCriteria_FirstName;
        var ln = page.advanceSearchClaimant.elements.searchCriteria_LastName;

        driver.findElement(fn).sendKeys(firstName);
        return driver.findElement(ln).sendKeys(lastName).then(function () {
            debugger;
            driver.findElement(button).click();
        });
    },
};