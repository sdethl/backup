module.exports = {

    elements: {
        at_a_glance: by.className('glanceModule__header__title'),
        critical_info: by.className('cardModule__header'),
        lien_history: by.className('base-data-table__title'),
        notes: by.css('section.root main.root__content div.root__content__main:nth-child(2) div.mui-container-fluid div.mui-row:nth-child(3) div.mui-container-fluid div.mui-row:nth-child(3) div.mui-col-md-12 section.base-data-table header.base-data-table__header > h3.base-data-table__title')
    },

    verifyModuleName: function(name){
        switch (name){
            case 'At A Glance':
                var modleName = page.lien.elements.at_a_glance;
                return driver.findElement(modleName).getText().then(function(text){
                    expect(text).to.equal("At A Glance");
                })
                break;
            case 'Critical Information':
                var modleName = page.lien.elements.critical_info;
                return driver.findElement(modleName).getText().then(function(text){
                    expect(text).to.equal("Critical Information");
                })
                break;
            case 'Lien History':
                var modleName = page.lien.elements.lien_history;
                return driver.findElement(modleName).getText().then(function(text){
                    expect(text).to.equal("Lien History");
                })
                break;
            case 'Notes':
                var modleName = page.lien.elements.notes;
                return driver.findElement(modleName).getText().then(function(text){
                    expect(text).to.equal("Notes");
                })
                break;
        }
    }
};