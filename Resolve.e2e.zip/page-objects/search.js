module.exports = {

    elements: {
        searchCriteriaInput: by.className('search-criterion__input'),
        searchButton: by.className('ura-button ura-button search-toolbar__button ura-button__primary')
    },

    preformSearch: function (searchQuery) {
        var selector = page.search.elements.searchCriteriaInput;
        var button = page.search.elements.searchButton;

        return driver.findElement(selector).sendKeys(searchQuery).then(function () {
            driver.findElement(button).click();
        });
    }
};